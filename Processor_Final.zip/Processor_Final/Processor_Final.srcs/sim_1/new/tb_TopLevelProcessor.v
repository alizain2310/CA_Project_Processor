//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:19:16 AM
// Design Name: 
// Module Name: tb_TopLevelProcessor
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

// ============================================================================
// Testbench: tb_TopLevelProcessor
// Purpose:   Simulates array_sum_stack.s (loaded from program.mem) and verifies:
//            - 3 new instructions (ori, andi, blt)
//            - Stack save/restore (sp=240, s0/x8=99, s1/x9=77)
//            - Final sum saved in Data Memory (mem[5] = 22) and output to LEDs
//            - Full memory reset when rst is pulsed
// ============================================================================
module tb_TopLevelProcessor;

    reg         clk      = 1'b0;       // Simulation clock
    reg         rst      = 1'b1;       // Active-high reset
    reg  [15:0] switches = 16'd0;      // Unused switches

    wire [15:0] leds;                  // Memory-mapped LED output (address 512)
    wire [31:0] pc_out;                // Current PC
    wire [31:0] instruction_out;       // Current 32-bit instruction
    wire [31:0] write_back_out;        // Data written back to Register File

    // Instantiate the RISC-V processor (Device Under Test)
    TopLevelProcessor dut (
        .clk(clk),
        .rst(rst),
        .switches(switches),
        .leds(leds),
        .pc_out(pc_out),
        .instruction_out(instruction_out),
        .write_back_out(write_back_out)
    );

    // 100 MHz simulation clock (10 ns period)
    always #5 clk = ~clk;

    initial begin
        // Step 1: Hold reset for 2 cycles to clear PC, Registers, RAM, and LEDs
        rst = 1'b1;
        repeat (2) @(posedge clk);
        #1 rst = 1'b0;

        // Step 2: Run 70 clock cycles (program finishes at cycle 54 and enters done)
        repeat (70) @(posedge clk);
        #1;

        // Step 3: Print verification results in Vivado Tcl Console
        $display("========================================================");
        $display("DataMem[20] (mem[5]) = %0d (Expected: 22)",  dut.mem_sys.dmem.mem[5]);
        $display("Register x6 (from LW)= %0d (Expected: 22)",  dut.rf.regs[6]);
        $display("Final LEDs Output    = %0d (Expected: 22)",  leds);
        $display("Stack Pointer sp(x2) = %0d (Expected: 240)", dut.rf.regs[2]);
        $display("Restored s0 (x8)     = %0d (Expected: 99)",  dut.rf.regs[8]);
        $display("Restored s1 (x9)     = %0d (Expected: 77)",  dut.rf.regs[9]);
        $display("========================================================");

        // Step 4: Test btnC Memory Reset (verify RAM and LEDs wipe to 0)
        rst = 1'b1;
        repeat (2) @(posedge clk);
        #1;
        $display("After Reset -> LEDs = %0d, DataMem[20] = %0d (Expected: 0, 0)",
                 leds, dut.mem_sys.dmem.mem[5]);

        $finish;
    end

endmodule
