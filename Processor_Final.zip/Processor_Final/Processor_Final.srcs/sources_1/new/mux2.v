`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:09:43 AM
// Design Name: 
// Module Name: mux2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: mux2
// Purpose: Simple 32-bit 2-to-1 multiplexer reused in three places:
//          1) pc_mux (PC+4 vs BranchTarget)
//          2) alu_src_mux (ReadData2 vs Imm)
//          3) mem_to_reg_mux (ALUResult vs MemReadData)
// ============================================================================
module mux2(
    input  wire [31:0] d0,             // Input selected when sel == 0
    input  wire [31:0] d1,             // Input selected when sel == 1
    input  wire        sel,            // 1-bit select control signal
    output wire [31:0] y               // Selected 32-bit output
);
    // If sel is 1 output d1; otherwise output d0
    assign y = sel ? d1 : d0;
endmodule
