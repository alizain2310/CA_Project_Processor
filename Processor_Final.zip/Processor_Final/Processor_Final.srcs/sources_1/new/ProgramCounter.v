`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:08:28 AM
// Design Name: 
// Module Name: ProgramCounter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: ProgramCounter
// Purpose: 32-bit flip-flop register that holds the byte address of the
//          current instruction being executed.
// ============================================================================
module ProgramCounter(
    input  wire        clk,            // CPU clock
    input  wire        rst,            // Synchronous reset (active high)
    input  wire [31:0] pc_next,        // Next instruction address from pc_mux
    output reg  [31:0] pc              // Current instruction address sent to Instruction Memory
);
    // Update PC strictly on the rising edge of the clock
    always @(posedge clk) begin
        if (rst)
            pc <= 32'd0;               // On reset, restart program from address 0x00000000
        else
            pc <= pc_next;             // Otherwise load the next instruction address
    end
endmodule

