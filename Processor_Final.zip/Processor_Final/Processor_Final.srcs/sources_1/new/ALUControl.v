//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:11:46 AM
// Design Name: 
// Module Name: ALUControl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: ALUControl
// Purpose: Selects the exact 4-bit ALU operation.
//          Added ALUOp == 2'b11 branch to support new I-type instructions
//          ORI (funct3 = 3'b110) and ANDI (funct3 = 3'b111).
// ============================================================================
module ALUControl(
    input  wire [1:0] ALUOp,           // From MainControl
    input  wire [2:0] funct3,          // instruction[14:12]
    input  wire [6:0] funct7,          // instruction[31:25]
    output reg  [3:0] ALUControl       // 4-bit control sent to ALU
);
    localparam AND_OP = 4'b0000;
    localparam OR_OP  = 4'b0001;
    localparam ADD_OP = 4'b0010;
    localparam XOR_OP = 4'b0011;
    localparam SLL_OP = 4'b0100;
    localparam SRL_OP = 4'b0101;
    localparam SUB_OP = 4'b0110;

    always @(*) begin
        case (ALUOp)
            2'b00: ALUControl = ADD_OP; // lw, sw, jalr address calculation
            2'b01: ALUControl = SUB_OP; // beq, blt comparison
            2'b10: begin                // R-type instructions
                case (funct3)
                    3'b000:  ALUControl = funct7[5] ? SUB_OP : ADD_OP;
                    3'b001:  ALUControl = SLL_OP;
                    3'b101:  ALUControl = SRL_OP;
                    3'b111:  ALUControl = AND_OP;
                    3'b110:  ALUControl = OR_OP;
                    3'b100:  ALUControl = XOR_OP;
                    default: ALUControl = ADD_OP;
                endcase
            end
            2'b11: begin                // I-type arithmetic & logic (addi, ori, andi)
                case (funct3)
                    3'b000:  ALUControl = ADD_OP; // addi
                    3'b110:  ALUControl = OR_OP;  // NEW INSTRUCTION 1: ori
                    3'b111:  ALUControl = AND_OP; // NEW INSTRUCTION 2: andi
                    default: ALUControl = ADD_OP;
                endcase
            end
            default: ALUControl = ADD_OP;
        endcase
    end
endmodule
