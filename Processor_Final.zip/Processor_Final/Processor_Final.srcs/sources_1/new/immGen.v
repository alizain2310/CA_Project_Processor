`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:10:16 AM
// Design Name: 
// Module Name: immGen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: immGen
// Purpose: Extracts and sign-extends immediate constants for I, S, B, and J
//          instruction formats.
// ============================================================================
module immGen(
    input  wire [31:0] instruction,    // 32-bit instruction from Instruction Memory
    output reg  [31:0] imm             // 32-bit sign-extended immediate output
);
    localparam OP_LOAD   = 7'b0000011; // lw   (I-type)
    localparam OP_I_ARTH = 7'b0010011; // addi, ori, andi (I-type)
    localparam OP_JALR   = 7'b1100111; // jalr (I-type)
    localparam OP_STORE  = 7'b0100011; // sw   (S-type)
    localparam OP_BRANCH = 7'b1100011; // beq, blt (B-type)
    localparam OP_JAL    = 7'b1101111; // jal  (J-type)

    always @(*) begin
        case (instruction[6:0])
            // I-type (lw, addi, ori, andi, jalr): 12-bit signed immediate in [31:20]
            OP_LOAD,
            OP_I_ARTH,
            OP_JALR:   imm = {{20{instruction[31]}}, instruction[31:20]};

            // S-type (sw): 12-bit signed immediate split across [31:25] and [11:7]
            OP_STORE:  imm = {{20{instruction[31]}}, instruction[31:25], instruction[11:7]};

            // B-type (beq, blt): 12-bit signed halfword offset (branchAdder shifts << 1)
            OP_BRANCH: imm = {{20{instruction[31]}}, instruction[31], instruction[7],
                              instruction[30:25], instruction[11:8]};

            // J-type (jal): 20-bit signed halfword offset (branchAdder shifts << 1)
            OP_JAL:    imm = {{12{instruction[31]}}, instruction[31], instruction[19:12],
                              instruction[20], instruction[30:21]};

            default:   imm = 32'd0;
        endcase
    end
endmodule