`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:09:22 AM
// Design Name: 
// Module Name: branchAdder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

// ============================================================================
// Module: branchAdder
// Purpose: Computes the target address for branch instructions (beq).
// Note:    immGen extracts the 12-bit signed branch offset without bit 0, so
//          shifting left by 1 (imm << 1) multiplies by 2 to make it a byte offset.
// ============================================================================
module branchAdder(
    input  wire [31:0] pc,             // Current PC of the branch instruction
    input  wire [31:0] imm,            // Sign-extended branch offset from immGen
    output wire [31:0] branch_target   // Destination PC address if branch is taken
);
    // PC-relative addressing: target = current PC + (offset * 2)
    assign branch_target = pc + (imm << 1);
endmodule
