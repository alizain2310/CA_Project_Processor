`timescale 1ns / 1ps

// ============================================================================
// Module: TopLevelProcessor
// Purpose: Complete single-cycle RV32I processor supporting base instructions,
//          procedure calls (jal, jalr), stack operations (lw/sw with sp), and
//          3 extra instructions: ORI, ANDI, and BLT.
// ============================================================================
module TopLevelProcessor(
    input  wire        clk,             // CPU clock (1 MHz on FPGA)
    input  wire        rst,             // Synchronous reset (clears PC, Regs, RAM, LEDs)
    input  wire [15:0] switches,        // 16-bit switch input (MMIO 768)
    output wire [15:0] leds,            // 16-bit LED output (MMIO 512)
    output wire [31:0] pc_out,          // Debug port: current PC
    output wire [31:0] instruction_out, // Debug port: current instruction
    output wire [31:0] write_back_out   // Debug port: Register File WriteData
);
    // ---------------- Internal Datapath Wires ----------------
    wire [31:0] pc, pc_plus4, branch_target, pc_branch_or_seq, pc_next;
    wire [31:0] instruction;
    wire [31:0] imm;
    wire [31:0] read_data1, read_data2;
    wire [31:0] alu_b, alu_result;
    wire [31:0] mem_read_data, wb_alu_or_mem, write_back;

    // ---------------- Internal Control Wires ----------------
    wire [3:0]  alu_control;
    wire [1:0]  alu_op;
    wire        reg_write, alu_src, mem_read, mem_write, mem_to_reg;
    wire        branch, jump, jalr;
    wire        zero, less_than;

    // Instruction funct3 field used to distinguish beq (000) from blt (100)
    wire [2:0]  funct3 = instruction[14:12];

    // Branch condition selector:
    //   funct3 == 3'b000 (beq) -> taken when Zero == 1 (rs1 == rs2)
    //   funct3 == 3'b100 (blt) -> taken when LessThan == 1 (rs1 < rs2)
    wire branch_cond = (funct3 == 3'b000) ? zero      :
                       (funct3 == 3'b100) ? less_than :
                                            1'b0;

    // Select PC + (imm << 1) for a taken branch OR an unconditional jal
    wire pc_src = (branch & branch_cond) | jump;

    // ==================== 1. INSTRUCTION FETCH STAGE ====================

    ProgramCounter pc_reg(
        .clk(clk),
        .rst(rst),
        .pc_next(pc_next),
        .pc(pc)
    );

    pcAdder pc_add(
        .pc(pc),
        .pc_plus4(pc_plus4)
    );

    // Computes PC + (imm << 1) for both conditional branches (beq/blt) and jal
    branchAdder br_add(
        .pc(pc),
        .imm(imm),
        .branch_target(branch_target)
    );

    // First PC mux: chooses PC + 4 vs. Branch/JAL target
    mux2 pc_mux(
        .d0(pc_plus4),
        .d1(branch_target),
        .sel(pc_src),
        .y(pc_branch_or_seq)
    );

    // Second PC mux: overrides with (rs1 + imm) during jalr return
    mux2 jalr_mux(
        .d0(pc_branch_or_seq),
        .d1({alu_result[31:1], 1'b0}),  // RV32I clears bit 0 of jalr target
        .sel(jalr),
        .y(pc_next)
    );

    instructionMemory imem(
        .instAddress(pc),
        .instruction(instruction)
    );

    // ==================== 2. DECODE & REGISTER STAGE ====================

    MainControl main_ctrl(
        .opcode(instruction[6:0]),
        .RegWrite(reg_write),
        .ALUOp(alu_op),
        .MemRead(mem_read),
        .MemWrite(mem_write),
        .ALUSrc(alu_src),
        .MemtoReg(mem_to_reg),
        .Branch(branch),
        .Jump(jump),
        .Jalr(jalr)
    );

    ALUControl alu_ctrl(
        .ALUOp(alu_op),
        .funct3(funct3),
        .funct7(instruction[31:25]),
        .ALUControl(alu_control)
    );

    RegisterFile rf(
        .clk(clk),
        .rst(rst),
        .WriteEnable(reg_write),
        .rs1(instruction[19:15]),
        .rs2(instruction[24:20]),
        .rd(instruction[11:7]),
        .WriteData(write_back),
        .ReadData1(read_data1),
        .ReadData2(read_data2)
    );

    immGen imm_gen(
        .instruction(instruction),
        .imm(imm)
    );

    // ==================== 3. EXECUTE (ALU) STAGE ====================

    mux2 alu_src_mux(
        .d0(read_data2),
        .d1(imm),
        .sel(alu_src),
        .y(alu_b)
    );

    ALU alu(
        .A(read_data1),
        .B(alu_b),
        .ALUControl(alu_control),
        .ALUResult(alu_result),
        .Zero(zero),
        .LessThan(less_than)
    );

    // ==================== 4. MEMORY & I/O STAGE ====================

    MemorySystem mem_sys(
        .clk(clk),
        .rst(rst),
        .address(alu_result),
        .readEnable(mem_read),
        .writeEnable(mem_write),
        .writeData(read_data2),
        .switches(switches),
        .readData(mem_read_data),
        .leds(leds)
    );

    // ==================== 5. WRITE-BACK STAGE ====================

    // First Write-Back mux: selects ALU result vs. Memory read data (lw)
    mux2 mem_to_reg_mux(
        .d0(alu_result),
        .d1(mem_read_data),
        .sel(mem_to_reg),
        .y(wb_alu_or_mem)
    );

    // Second Write-Back mux: saves PC + 4 into rd during jal / jalr
    mux2 wb_jump_mux(
        .d0(wb_alu_or_mem),
        .d1(pc_plus4),
        .sel(jump | jalr),
        .y(write_back)
    );

    assign pc_out          = pc;
    assign instruction_out = instruction;
    assign write_back_out  = write_back;
endmodule