
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:11:17 AM
// Design Name: 
// Module Name: MainControl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

// ============================================================================
// Module: MainControl
// Purpose: Decodes the 7-bit opcode into datapath control signals.
//          Modified to support I-type logic (ori, andi) via ALUOp = 2'b11,
//          plus jal and jalr for stack-based procedure calls.
// ============================================================================
module MainControl(
    input  wire [6:0] opcode,          // instruction[6:0]
    output reg        RegWrite,        // Write result to Register File
    output reg  [1:0] ALUOp,           // 00=ADD, 01=SUB/Compare, 10=R-type, 11=I-arith
    output reg        MemRead,         // Read from MemorySystem (lw)
    output reg        MemWrite,        // Write to MemorySystem (sw)
    output reg        ALUSrc,          // 0 = rs2, 1 = immediate
    output reg        MemtoReg,        // 0 = ALU result, 1 = Memory data
    output reg        Branch,          // Conditional branch (beq, blt)
    output reg        Jump,            // Unconditional jump and link (jal)
    output reg        Jalr             // Jump and link register (jalr)
);
    localparam R_TYPE  = 7'b0110011;   // add, sub, sll, srl, and, or, xor
    localparam I_ARITH = 7'b0010011;   // addi, ori, andi
    localparam LOAD    = 7'b0000011;   // lw
    localparam STORE   = 7'b0100011;   // sw
    localparam BRANCH  = 7'b1100011;   // beq, blt
    localparam JAL_OP  = 7'b1101111;   // jal
    localparam JALR_OP = 7'b1100111;   // jalr

    always @(*) begin
        // Safe defaults to prevent inferred latches
        RegWrite = 1'b0;
        ALUOp    = 2'b00;
        MemRead  = 1'b0;
        MemWrite = 1'b0;
        ALUSrc   = 1'b0;
        MemtoReg = 1'b0;
        Branch   = 1'b0;
        Jump     = 1'b0;
        Jalr     = 1'b0;

        case (opcode)
            R_TYPE: begin
                RegWrite = 1'b1;
                ALUOp    = 2'b10;      // Decode R-type using funct3 and funct7
            end
            I_ARITH: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;       // Use immediate as ALU operand B
                ALUOp    = 2'b11;      // Decode addi, ori, andi using funct3
            end
            LOAD: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                MemRead  = 1'b1;
                MemtoReg = 1'b1;       // Write memory data to rd
            end
            STORE: begin
                ALUSrc   = 1'b1;
                MemWrite = 1'b1;
            end
            BRANCH: begin
                ALUOp    = 2'b01;      // Subtract/compare rs1 and rs2 for beq/blt
                Branch   = 1'b1;
            end
            JAL_OP: begin
                RegWrite = 1'b1;       // Save PC + 4 into rd (x1)
                Jump     = 1'b1;       // Jump to PC + (imm << 1)
            end
            JALR_OP: begin
                RegWrite = 1'b1;       // Save PC + 4 into rd (ignored if rd = x0)
                ALUSrc   = 1'b1;       // ALU computes rs1 + imm (return address)
                Jalr     = 1'b1;       // Jump PC to ALU result
            end
            default: ;
        endcase
    end
endmodule