`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:12:50 AM
// Design Name: 
// Module Name: RegisterFile
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

// ============================================================================
// Module: RegisterFile
// Purpose: Implements the 32 general-purpose 32-bit RISC-V registers (x0..x31)
//          with 2 combinational read ports and 1 synchronous write port.
// ============================================================================
module RegisterFile(
    input  wire        clk,            // CPU clock
    input  wire        rst,            // Synchronous reset (clears all registers to 0)
    input  wire        WriteEnable,    // RegWrite signal from MainControl
    input  wire [4:0]  rs1,            // 5-bit address of source register 1 (0..31)
    input  wire [4:0]  rs2,            // 5-bit address of source register 2 (0..31)
    input  wire [4:0]  rd,             // 5-bit address of destination register (0..31)
    input  wire [31:0] WriteData,      // 32-bit value to write into regs[rd]
    output wire [31:0] ReadData1,      // 32-bit value read from regs[rs1]
    output wire [31:0] ReadData2       // 32-bit value read from regs[rs2]
);
    // 32 registers, each 32 bits wide
    reg [31:0] regs [0:31];
    integer i;

    // Combinational reads: RISC-V hardwires register x0 to always return 0
    assign ReadData1 = (rs1 == 5'd0) ? 32'd0 : regs[rs1];
    assign ReadData2 = (rs2 == 5'd0) ? 32'd0 : regs[rs2];

    // Synchronous write on rising clock edge
    always @(posedge clk) begin
        if (rst) begin
            // Clear all 32 registers to 0 on reset
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'd0;
        end else if (WriteEnable && (rd != 5'd0)) begin
            // Write new data ONLY if RegWrite=1 AND destination is not x0
            regs[rd] <= WriteData;
        end
    end
endmodule
