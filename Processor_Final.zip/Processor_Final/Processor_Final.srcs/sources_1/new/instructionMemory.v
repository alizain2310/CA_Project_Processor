`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:10:45 AM
// Design Name: 
// Module Name: instructionMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

// ============================================================================
// Module: instructionMemory
// Purpose: 64-word ROM holding the single assembled RISC-V program loaded
//          from "program.mem".
// ============================================================================
module instructionMemory(
    input  wire [31:0] instAddress,    // Byte address from ProgramCounter (PC)
    output wire [31:0] instruction     // 32-bit instruction output
);
    reg [31:0] memory [0:63];
    integer i;

    initial begin
        // Pre-fill unused memory slots with NOP (addi x0, x0, 0)
        for (i = 0; i < 64; i = i + 1)
            memory[i] = 32'h00000013;

        // Load your Venus hex dump for the array summation program
        $readmemh("program.mem", memory);
    end

    // Convert byte address (0, 4, 8...) to word index (0, 1, 2...)
    assign instruction = memory[instAddress[7:2]];
endmodule