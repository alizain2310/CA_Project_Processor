`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:14:50 AM
// Design Name: 
// Module Name: switches
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

// ============================================================================
// Module: switches (Lab 5 provided module name � drives the 16 FPGA LEDs)
// Purpose: Latches the lower 16 bits of writeData into the LED register
//          whenever the CPU executes "sw xReg, 512(x0)".
// ============================================================================
module switches(
    input  wire        clk,            // CPU clock
    input  wire        rst,            // Synchronous reset
    input  wire [31:0] writeData,      // 32-bit register data from CPU
    input  wire        writeEnable,    // LEDWrite signal from AddressDecoder
    input  wire        readEnable,     // Unused (LEDs are write-only)
    input  wire [29:0] memAddress,     // Unused (single 16-bit LED register)
    output reg  [31:0] readData = 32'd0, // Unused read output
    output reg  [15:0] leds            // 16-bit register connected to physical LEDs
);
    // Update the LEDs on rising clock edge so the output stays lit steadily
    always @(posedge clk) begin
        if (rst)
            leds <= 16'd0;             // Turn all LEDs OFF on reset
        else if (writeEnable)
            leds <= writeData[15:0];   // Display lower 16 bits of stored value on LEDs
    end
endmodule
