`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:06:48 AM
// Design Name: 
// Module Name: debouncer
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

// ============================================================================
// Module: debouncer
// Purpose: Lab 5 button interface wrapper that passes the reset button signal
//          to the processor.
// ============================================================================
module debouncer(
    input  wire clk,                   // System clock input
    input  wire pbin,                  // Raw pushbutton input from Basys 3
    output wire pbout                  // Output reset signal to CPU
);
    // Directly forward the pushbutton state to the output
    assign pbout = pbin;
endmodule
