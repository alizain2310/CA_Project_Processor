`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:06:17 AM
// Design Name: 
// Module Name: clock_divider
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

// ============================================================================
// Module: clock_divider
// Purpose: Divides the 100 MHz Basys 3 board clock down to 1 MHz as required
//          by the Course Project specification.
// Math:    100,000,000 Hz / (2 * 50) = 1,000,000 Hz (1 MHz)
// ============================================================================
module clock_divider(
    input  wire clk_in,                // 100 MHz board clock
    input  wire rst,                   // Synchronous reset
    output reg  clk_out = 1'b0         // 1 MHz output clock for the CPU
);
    // Toggle clk_out every 50 ticks of the 100 MHz clock -> 1 MHz full period
    localparam HALF_PERIOD = 50;
    reg [31:0] count = 32'd0;

    always @(posedge clk_in) begin
        if (rst) begin
            count   <= 32'd0;
            clk_out <= 1'b0;
        end else if (count == HALF_PERIOD - 1) begin
            count   <= 32'd0;          // Restart counter
            clk_out <= ~clk_out;       // Flip 1 MHz output clock
        end else begin
            count <= count + 32'd1;    // Keep counting
        end
    end
endmodule
