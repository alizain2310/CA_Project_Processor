//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:05:28 AM
// Design Name: 
// Module Name: top_fpga
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: top_fpga
// Purpose: Top-level FPGA wrapper connecting the Basys 3 100 MHz clock,
//          btnC (full processor + Data Memory reset), 16 switches, and 16 LEDs
//          to the single-cycle RISC-V processor running at 1 MHz.
// ============================================================================
module top_fpga(
    input  wire        clk,            // 100 MHz Basys 3 clock (Pin W5)
    input  wire        btnC,           // Center button (Pin U18): Full CPU & RAM reset
    input  wire [15:0] physical_sw,    // 16 slide switches (SW15..SW0)
    output wire [15:0] physical_leds   // 16 physical LEDs (LD15..LD0)
);
    wire rst_clean;                    // Clean reset signal from debouncer
    wire clk_cpu;                      // 1 MHz processor clock

    // Step 1: Pass btnC through the Lab 5 debouncer module
    debouncer rst_db(
        .clk(clk),
        .pbin(btnC),
        .pbout(rst_clean)
    );

    // Step 2: Generate the required 1 MHz processor clock from 100 MHz
    clock_divider clk_div(
        .clk_in(clk),
        .rst(1'b0),                    // Keep clock running even during CPU reset
        .clk_out(clk_cpu)
    );

    // Step 3: Instantiate the single-cycle RISC-V processor
    // Holding btnC clears PC, Register File, Data Memory, and LEDs to 0.
    // Releasing btnC executes the program and shows the result from RAM on LEDs.
    TopLevelProcessor cpu(
        .clk(clk_cpu),
        .rst(rst_clean),
        .switches(physical_sw),
        .leds(physical_leds),
        .pc_out(),                     // Simulation debug only
        .instruction_out(),            // Simulation debug only
        .write_back_out()              // Simulation debug only
    );
endmodule
