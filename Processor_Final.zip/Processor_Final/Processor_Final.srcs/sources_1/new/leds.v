`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:15:28 AM
// Design Name: 
// Module Name: leds
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

// ============================================================================
// Module: leds (Lab 5 provided module name - reads the 16 FPGA Switches)
// Purpose: Zero-extends the 16 physical slide switches into a 32-bit word
//          so the CPU can read them using "lw xReg, 768(x0)".
// ============================================================================
module leds(
    input  wire        clk,            // CPU clock (unused for combinational read)
    input  wire        rst,            // Reset (unused)
    input  wire [15:0] btns,           // Unused button input
    input  wire [31:0] writeData,      // Unused (switches are read-only)
    input  wire        writeEnable,    // Unused (switches are read-only)
    input  wire        readEnable,     // SwitchReadEnable from AddressDecoder
    input  wire [29:0] memAddress,     // Unused
    input  wire [15:0] switches,       // Physical slide switch states from Basys 3
    output wire [31:0] readData        // 32-bit zero-extended switch value sent to CPU
);
    // Pad the upper 16 bits with zeros and place switches[15:0] in the lower 16 bits
    assign readData = {16'd0, switches};
endmodule