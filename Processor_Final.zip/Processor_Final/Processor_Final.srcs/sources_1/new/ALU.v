//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:12:30 AM
// Design Name: 
// Module Name: ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: ALU
// Purpose: 32-bit ALU with Zero flag (for beq) and signed LessThan flag
//          (for the new BLT instruction).
// ============================================================================
module ALU(
    input  wire [31:0] A,              // Operand 1 (rs1)
    input  wire [31:0] B,              // Operand 2 (rs2 or immediate)
    input  wire [3:0]  ALUControl,     // 4-bit operation code
    output reg  [31:0] ALUResult,      // 32-bit computed result
    output wire        Zero,           // 1 when ALUResult == 0 (used by beq)
    output wire        LessThan        // 1 when signed A < signed B (NEW: used by blt)
);
    always @(*) begin
        case (ALUControl)
            4'b0000: ALUResult = A & B;          // AND / ANDI
            4'b0001: ALUResult = A | B;          // OR  / ORI
            4'b0010: ALUResult = A + B;          // ADD / ADDI / LW / SW / JALR
            4'b0011: ALUResult = A ^ B;          // XOR
            4'b0100: ALUResult = A << B[4:0];    // SLL
            4'b0101: ALUResult = A >> B[4:0];    // SRL
            4'b0110: ALUResult = A - B;          // SUB / BEQ / BLT
            default: ALUResult = 32'd0;
        endcase
    end

    // Zero flag for beq (rs1 == rs2)
    assign Zero     = (ALUResult == 32'd0);

    // NEW INSTRUCTION 3 (blt): signed comparison rs1 < rs2
    assign LessThan = ($signed(A) < $signed(B));
endmodule
