`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:14:22 AM
// Design Name: 
// Module Name: DataMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: DataMemory
// Purpose: 64 x 32-bit Data Memory (RAM) covering byte addresses 0..255.
//          Uses 64 words (2,048 flip-flops) so Vivado synthesizes a full
//          synchronous reset quickly on the Basys 3 FPGA without running out
//          of resources.
// ============================================================================
module DataMemory(
    input  wire        clk,            // CPU clock
    input  wire        rst,            // Synchronous reset (clears all 64 words to 0)
    input  wire        MemWrite,       // Write enable from AddressDecoder (1 during sw)
    input  wire [5:0]  address,        // 6-bit word address (0..63)
    input  wire [31:0] write_data,     // 32-bit word to write into RAM
    output wire [31:0] read_data       // 32-bit word read from RAM
);
    // 64-word memory array (each entry holds one 32-bit integer)
    reg [31:0] mem [0:63];
    integer i;

    // Synchronous reset and write on rising clock edge
    always @(posedge clk) begin
        if (rst) begin
            // Wipe every memory location back to 0 when any reset button is pressed
            for (i = 0; i < 64; i = i + 1)
                mem[i] <= 32'd0;
        end else if (MemWrite) begin
            // Store new 32-bit word at the requested word index
            mem[address] <= write_data;
        end
    end

    // Combinational read: immediately outputs the word stored at "address"
    assign read_data = mem[address];
endmodule
