`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:13:43 AM
// Design Name: 
// Module Name: AddressDecoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

// ============================================================================
// Module: AddressDecoder
// Purpose: Inspects the top bits of the 10-bit local address (address[9:8])
//          to route load/store instructions to the right hardware block.
//
// Memory Map:
//   0   .. 511  (address[9] == 0)              -> Data Memory (Read & Write)
//   512 .. 767  (address[9] == 1, [8] == 0)    -> LEDs        (Write Only)
//   768 .. 1023 (address[9] == 1, [8] == 1)    -> Switches    (Read Only)
// ============================================================================
module AddressDecoder(
    input  wire [9:0] address,         // Lower 10 bits of ALU memory address
    input  wire       readEnable,      // MemRead from MainControl
    input  wire       writeEnable,     // MemWrite from MainControl
    output wire       DataMemWrite,    // Write enable for RAM
    output wire       DataMemRead,     // Read enable for RAM
    output wire       LEDWrite,        // Write enable for LEDs
    output wire       SwitchReadEnable // Read enable for Switches
);
    // Decode which memory-mapped device is being addressed
    wire DataMemSelect = ~address[9];               // True for addresses 0 to 511
    wire LEDSelect     =  address[9] & ~address[8]; // True for addresses 512 to 767
    wire SwitchSelect  =  address[9] &  address[8]; // True for addresses 768 to 1023

    // Gate each device select with the CPU's read/write control signal
    assign DataMemWrite     = DataMemSelect & writeEnable;
    assign DataMemRead      = DataMemSelect & readEnable;
    assign LEDWrite         = LEDSelect     & writeEnable;
    assign SwitchReadEnable = SwitchSelect  & readEnable;
endmodule
