`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2026 10:09:04 AM
// Design Name: 
// Module Name: pcAdder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns / 1ps

// ============================================================================
// Module: pcAdder
// Purpose: Combinational adder that calculates the next sequential instruction
//          address (PC + 4 bytes).
// ============================================================================
module pcAdder(
    input  wire [31:0] pc,             // Current PC value
    output wire [31:0] pc_plus4        // Address of the next sequential 32-bit instruction
);
    // Add 4 bytes because every RV32I instruction is 32 bits (4 bytes) wide
    assign pc_plus4 = pc + 32'd4;
endmodule
